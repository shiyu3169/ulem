import React, { Component } from "react";

export default class Thank extends Component {
  render() {
    return (
      <div style={{ minHeight: "100vh" }}>
        <h1 className="text-center mt-5">
          Thank you for your time, we will contact you soon
        </h1>
      </div>
    );
  }
}
